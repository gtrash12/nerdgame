﻿using System;
using System.Collections;
using System.Collections.Generic;
using Bolt;
using GoogleMobileAds.Api;
using Ludiq;
using UnityEngine;

public class RewardedAdFunction : MonoBehaviour {
    public static void RewardedAdAddFunction (RewardedAd rewardedAd) {
        // Called when an ad request has successfully loaded.
        rewardedAd.OnAdLoaded += HandleRewardedAdLoaded;
        // Called when an ad request failed to load.
        rewardedAd.OnAdFailedToLoad += HandleRewardedAdFailedToLoad;
        // Called when an ad is shown.
        rewardedAd.OnAdOpening += HandleRewardedAdOpening;
        // Called when an ad request failed to show.
        rewardedAd.OnAdFailedToShow += HandleRewardedAdFailedToShow;
        // Called when the user should be rewarded for interacting with the ad.
        rewardedAd.OnUserEarnedReward += HandleUserEarnedReward;
        // Called when the ad is closed.
        rewardedAd.OnAdClosed += HandleRewardedAdClosed;
    }

    public static void HandleRewardedAdLoaded (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "RewardLoad");

        MonoBehaviour.print ("HandleRewardedAdLoaded event received");
    }

    public static void HandleRewardedAdFailedToLoad (object sender, AdErrorEventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "RewardLoadFail");

        MonoBehaviour.print (
            "HandleRewardedAdFailedToLoad event received with message: " +
            args.Message);
    }

    public static void HandleRewardedAdOpening (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "RewardOpen");

        MonoBehaviour.print ("HandleRewardedAdOpening event received");
    }

    public static void HandleRewardedAdFailedToShow (object sender, AdErrorEventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "RewardOpenFail");

        MonoBehaviour.print (
            "HandleRewardedAdFailedToShow event received with message: " +
            args.Message);
    }

    public static void HandleRewardedAdClosed (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "RewardClose");

        MonoBehaviour.print ("HandleRewardedAdClosed event received");
    }

    public static void HandleUserEarnedReward (object sender, Reward args) {
        string type = args.Type;
        double amount = args.Amount;
        MonoBehaviour.print (
            "HandleRewardedAdRewarded event received for " +
            amount.ToString () + " " + type);

        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "RewardGet", args.Type, args.Amount);
    }
}