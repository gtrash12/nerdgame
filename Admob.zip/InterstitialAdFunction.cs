﻿using System;
using System.Collections;
using System.Collections.Generic;
using Bolt;
using GoogleMobileAds.Api;
using Ludiq;
using UnityEngine;

public class InterstitialAdFunction : MonoBehaviour {
    public static void InterstitialAdAddFunction (InterstitialAd InterstitialAdGet) {
        // Called when an ad request has successfully loaded.
        InterstitialAdGet.OnAdLoaded += HandleOnAdLoaded;
        // Called when an ad request failed to load.
        InterstitialAdGet.OnAdFailedToLoad += HandleOnAdFailedToLoad;
        // Called when an ad is shown.
        InterstitialAdGet.OnAdOpening += HandleOnAdOpened;
        // Called when the ad is closed.
        InterstitialAdGet.OnAdClosed += HandleOnAdClosed;
        // Called when the ad click caused the user to leave the application.
        InterstitialAdGet.OnAdLeavingApplication += HandleOnAdLeavingApplication;
    }

    public static void HandleOnAdLoaded (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "AdLoad");

        MonoBehaviour.print ("HandleAdLoaded event received");
    }

    public static void HandleOnAdFailedToLoad (object sender, AdFailedToLoadEventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "AdLoadFail");

        print ("Interstitial failed to load: " + args.Message);
        // Handle the ad failed to load event.
    }

    public static void HandleOnAdOpened (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "AdOpen");

        MonoBehaviour.print ("HandleAdOpened event received");
    }

    public static void HandleOnAdClosed (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "AdClose");

        MonoBehaviour.print ("HandleAdClosed event received");
    }

    public static void HandleOnAdLeavingApplication (object sender, EventArgs args) {
        var adManager = GameObject.Find ("AdManager");
        CustomEvent.Trigger (adManager, "AdClick");

        MonoBehaviour.print ("HandleAdLeavingApplication event received");
    }
}